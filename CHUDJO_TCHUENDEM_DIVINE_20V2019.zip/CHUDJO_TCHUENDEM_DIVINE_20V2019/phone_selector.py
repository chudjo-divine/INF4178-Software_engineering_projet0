import tkinter as tk
from tkinter import messagebox
import numpy as np

# Liste des téléphones disponibles
phones = [
    "Iphone 12", "Itel A56", "Tecno Camon 12", "Infinix Hot 10",
    "Huawei P30", "Google Pixel 7", "Xiaomi Redmi Note 10",
    "Samsung Galaxy S22", "Motorola Razr+", "Iphone XR", "Samsung Galaxy Note 10"
]

# Critères pour évaluer les téléphones avec leurs unités
criteria = [
    ("Stockage", "GB"),
    ("CPU", "Hz"),
    ("Prix", "FCFA"),
    ("Marque", ""),
    ("Mémoire", "GB")
]

# Instructions pour l'échelle AHP
AHP_SCALE_HELP = (
    "\nAide pour les valeurs de comparaison :\n"
    "1 - Importance égale\n"
    "3 - Importance modérée\n"
    "5 - Importance forte\n"
    "7 - Importance très forte\n"
    "9 - Importance extrême\n"
    "2, 4, 6, 8 - Valeurs intermédiaires\n"
    "1/3, 1/5, 1/7, 1/9 - Valeurs inverses\n"
)

class AHPApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sélecteur de Téléphone AHP")

        # Matrice de comparaison des critères
        self.criteria_matrix = np.eye(len(criteria))  
        self.phone_scores = np.zeros(len(phones))  # Initialisation des scores des téléphones
        self.current_criterion = 0  # Indice pour le critère actuel
        self.phase = "criteria_comparison"  # Phase actuelle de l'application

        # Instructions à l'utilisateur
        self.instructions = tk.Label(root, text="Évaluez l'importance des critères (voir l'aide ci-dessous)")
        self.instructions.pack()

        # Aide pour l'échelle AHP
        self.help_label = tk.Label(root, text=AHP_SCALE_HELP, justify=tk.LEFT, fg="blue")
        self.help_label.pack()

        # Cadre pour les entrées
        self.form_frame = tk.Frame(root)
        self.form_frame.pack()

        self.create_criteria_inputs()  # Création des champs de saisie pour comparer les critères

        # Bouton pour passer à l'étape suivante
        self.next_button = tk.Button(root, text="Suivant", command=self.next_step)
        self.next_button.pack(pady=10)

    def create_criteria_inputs(self):
        """Création des champs de saisie pour comparer les critères."""
        for widget in self.form_frame.winfo_children():
            widget.destroy()  # Nettoyage des champs existants

        self.entries = []  # Liste pour stocker les champs de saisie
        for i in range(len(criteria)):
            for j in range(len(criteria)):
                row = tk.Frame(self.form_frame)
                label = tk.Label(row, text=f"Comparer {criteria[i][0]} avec {criteria[j][0]} :", width=30)
                entry = tk.Entry(row)  # Champ de saisie pour la comparaison
                row.pack(pady=2)
                label.pack(side=tk.LEFT)
                entry.pack(side=tk.RIGHT)
                self.entries.append((entry, i, j))  # Enregistrement du champ et des indices

                # Diagonale à 1 pour chaque critère
                if i == j:
                    self.criteria_matrix[i][j] = 1

    def next_step(self):
        """Passage à l'étape suivante selon la phase actuelle."""
        if self.phase == "criteria_comparison":
            try:
                # Remplissage de la matrice de comparaison des critères
                for entry, i, j in self.entries:
                    value = float(entry.get())
                    self.criteria_matrix[i][j] = value  # Valeur saisie
                    self.criteria_matrix[j][i] = 1 / value  # Symétrie

                # Normalisation de la matrice de comparaison
                self.criteria_normalized = self.normalize_matrix(self.criteria_matrix)
                self.criteria_vector = self.calculate_priority_vector(self.criteria_normalized)

                # Passage à l'évaluation des téléphones
                self.phase = "phone_comparison"
                self.current_criterion = 0
                self.show_phone_inputs()  # Affichage des champs pour évaluer les téléphones
            except ValueError:
                messagebox.showerror("Erreur", "Veuillez entrer des chiffres valides.")

        elif self.phase == "phone_comparison":
            try:
                # Récupération des scores des téléphones
                scores = [float(e.get()) for e in self.entries]  # Valeurs saisies
                matrix = self.create_comparison_matrix(scores)  # Création de la matrice de comparaison
                norm = self.normalize_matrix(matrix)  # Normalisation
                pv = self.calculate_priority_vector(norm)  # Vecteur de priorité
                self.phone_scores += pv * self.criteria_vector[self.current_criterion]  # Mise à jour des scores
                self.current_criterion += 1

                if self.current_criterion < len(criteria):
                    self.show_phone_inputs()  # Affichage pour le prochain critère
                else:
                    self.check_consistency()  # Vérification de la cohérence
            except ValueError:
                messagebox.showerror("Erreur", "Veuillez entrer des chiffres valides.")

    def show_phone_inputs(self):
        """Affichage des champs de saisie pour évaluer les téléphones selon le critère actuel."""
        for widget in self.form_frame.winfo_children():
            widget.destroy()  # Nettoyage des champs existants

        current_criterion = criteria[self.current_criterion]
        self.instructions.config(text=f"Évaluez chaque téléphone pour le critère : {current_criterion[0]} ({current_criterion[1]})")
        self.entries = []  # Réinitialisation de la liste des entrées
        for phone in phones:
            row = tk.Frame(self.form_frame)
            label = tk.Label(row, text=phone, width=25)
            entry = tk.Entry(row)  # Champ de saisie pour chaque téléphone
            row.pack(pady=2)
            label.pack(side=tk.LEFT)
            entry.pack(side=tk.RIGHT)
            self.entries.append(entry)  # Ajout des champs de saisie pour les téléphones

    def create_comparison_matrix(self, scores):
        """Création d'une matrice de comparaison à partir des scores des téléphones."""
        size = len(scores)
        matrix = np.ones((size, size))  # Matrice initialisée avec des 1
        for i in range(size):
            for j in range(size):
                if i != j:
                    matrix[i][j] = scores[i] / scores[j]  # Remplissage des rapports
        return matrix

    def normalize_matrix(self, matrix):
        """Normalisation de la matrice en divisant chaque élément par la somme de sa colonne."""
        column_sums = np.sum(matrix, axis=0)  # Sommes de chaque colonne
        return matrix / column_sums  # Retour de la matrice normalisée

    def calculate_priority_vector(self, normalized_matrix):
        """Calcul du vecteur de priorité en prenant la moyenne de chaque ligne."""
        return np.mean(normalized_matrix, axis=1)  # Moyenne des lignes

    def check_consistency(self):
        """Vérification de la cohérence des jugements de l'utilisateur."""
        consistency_index = self.calculate_consistency_index()  # Calcul de l'indice de cohérence
        random_index = 1.12  # RI pour 5 critères
        consistency_ratio = consistency_index / random_index  # Ratio de cohérence

        if consistency_ratio < 0.1:
            self.show_results()  # Affichage des résultats si cohérence acceptable
        else:
            messagebox.showinfo("Cohérence", "La cohérence des jugements n'est pas acceptable. Veuillez réévaluer.")

    def calculate_consistency_index(self):
        """Calcul de l'indice de cohérence (CI)."""
        weighted_sums = np.dot(self.criteria_matrix, self.criteria_vector)  # Produit de la matrice et des poids
        ci = (np.sum(weighted_sums) / len(criteria) - len(criteria)) / (len(criteria) - 1)  # Calcul de CI
        return ci

    def show_results(self):
        """Affichage des résultats finaux après évaluation de tous les critères."""
        best_index = np.argmax(self.phone_scores)  # Indice du meilleur téléphone
        messagebox.showinfo("Résultat", f"Le téléphone recommandé est : {phones[best_index]}")

        # Affichage des scores finaux dans une nouvelle fenêtre
        result_window = tk.Toplevel(self.root)
        result_window.title("Scores finaux")
        for i in range(len(phones)):
            label = tk.Label(result_window, text=f"{phones[i]}: {round(self.phone_scores[i], 4)}")
            label.pack()

        self.root.destroy()  # Fermeture de l'application principale

if __name__ == "__main__":
    root = tk.Tk()  # Création de la fenêtre principale
    app = AHPApp(root)  # Initialisation de l'application AHP
    root.mainloop()  # Démarrage de la boucle de l'application